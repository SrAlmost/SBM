#ifndef _PWM_H
	#define _PWM_H
		/*---------------------------JOYSTICK--------------------------------------------*/
			int Init_pwm(void); //funcion para crear el hilo del joystick
			
#endif
