#include "stm32f4xx_hal.h"
#include "cmsis_os2.h"

#ifndef _THLED1_H
  #define _THLED1_H
    int Init_Thled1(void);
#endif
#define S_LED1 0x00000001U