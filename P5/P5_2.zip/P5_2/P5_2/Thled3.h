#include "stm32f4xx_hal.h"

#ifndef _THLED3_H
  #define _THLED3_H
    int Init_Thled3(void);
#endif
