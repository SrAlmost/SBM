#include "stm32f4xx_hal.h"
#include "cmsis_os2.h"

#ifndef _THLED3_H
  #define _THLED3_H
    int Init_Thled3(void);
  
#endif
#define S_LED2 0x00000002U
#define S_LED3 0x00000003U