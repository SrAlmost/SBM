#include "stm32f4xx_hal.h"
#include "cmsis_os2.h"

#ifndef _THLED2_H
  #define _THLED2_H
    int Init_Thled2(void);
#endif
#define S_LED2 0x00000002U
#define S_LED3 0x00000003U