#include "stm32f4xx_hal.h"

#ifndef _THLED1_H
  #define _THLED1_H
    int Init_Thled1(void);
#endif
