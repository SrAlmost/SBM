#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "principal.h"

#include "joystick.h"
#include "lcd.h"
#include "clock.h"

#include "string.h"
#include <stdio.h>

/*-------------------------- VARIABLES ------------------------------*/	
	/*-------------------------- COLAS MENSAJES ------------------------------*/	
osMessageQueueId_t mid_MsgQueueJOY;                // message queue id 
osMessageQueueId_t mid_MsgQueueLCD;                // message queue id 
	/*-------------------------- JOYSTICK ------------------------------*/	
static informacion_t pulsacion;
	/*------------------ TEMPERATURA ---------------------*/	
static double temREF = 25.0; //temperatura de referencia
static double temMED; //temperatura medida
	/*------------------ PWM ---------------------*/	
static uint8_t PWM; //ciclo de trabajo	
	/*-------------------------- HILO ------------------------------*/	
osThreadId_t tid_principal;                        // thread id
Modo modos = REPOSO; //modo de funcionamiento del sistema
 
/*------------------ DECLARACION FUNCIONES NO GLOBALES ---------------------*/	
	/*------------------ COLAS DE MENSAJES ---------------------*/	
static int Init_MsgQueue (void) ;
	/*------------------ HILO PRINCIPAL ---------------------*/	
void principal (void *argument); 									// thread function
int Init_principal (void);
static void modoFuncionamiento(void); 
	/*------------------ MODOS FUNCIONAMIENTO ---------------------*/	
static void reposo(void);
static void activo(void);
static void test(void);
static void programacion(void);
//static uint8_t generarPWM( double referencia, double medida );
                  
 
/*-------------------------- CODIGO FUNCIONES ------------------------------*/	 
static int Init_MsgQueue (void) {
 
  mid_MsgQueueJOY = osMessageQueueNew(4, sizeof(informacion_t), NULL);
  if (mid_MsgQueueJOY == NULL) {
    return -1;
  }
	
	mid_MsgQueueLCD = osMessageQueueNew(2, sizeof(escribir_t), NULL);
  if (mid_MsgQueueLCD == NULL) {
    return -1;
  }
	
	return 0;
} 
 
int Init_principal (void) {
	//Creacion colas de mensajes
	if( Init_MsgQueue() != 0){
		return -1;
	}
 
  tid_principal = osThreadNew(principal, NULL, NULL);
  if (tid_principal == NULL) {
    return(-1);
  }
 
  return(0);
}

static void reposo(void){
	escribir_t infoReposo;
	infoReposo.linea = 1;
	sprintf(infoReposo.inf, "     SBM 2023");
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
	infoReposo.linea = 2;
	sprintf(infoReposo.inf, "      %d%d:%d%d:%d%d", horas/10, horas%10, minutos/10, minutos%10, segundos/10, segundos%10);
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
}

static void activo(void){
	escribir_t infoReposo;
	infoReposo.linea = 1;
	sprintf(infoReposo.inf, "    ACT---%d%d:%d%d:%d%d---", horas/10, horas%10, minutos/10, minutos%10, segundos/10, segundos%10);
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
	infoReposo.linea = 2;
	temMED = 23.2;
	PWM = 70;
	sprintf(infoReposo.inf, "  Tm:%1.f-Tr:%1.f-D:%d%%", temMED, temREF, PWM);
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
}

static void test(void){
	escribir_t infoReposo;
	infoReposo.linea = 1;
	sprintf(infoReposo.inf, "   TEST---%d%d:%d%d:%d%d---", horas/10, horas%10, minutos/10, minutos%10, segundos/10, segundos%10);
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
	infoReposo.linea = 2;
	temMED = 23.2;
	PWM = 70;
	sprintf(infoReposo.inf, "  Tm:%1.f-Tr:%1.f-D:%d%%", temMED, temREF, PWM);
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
}

static void programacion(void){
	escribir_t infoReposo;
	infoReposo.linea = 1;
	sprintf(infoReposo.inf, "      ---P&D---");
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
	infoReposo.linea = 2;
	sprintf(infoReposo.inf, "   H:%d%d:%d%d:%d%d---Tr:%1.f", horas/10, horas%10, minutos/10, minutos%10, segundos/10, segundos%10, temREF);
	osMessageQueuePut(mid_MsgQueueLCD, &infoReposo, 0U, 0U);
}
 
static void modoFuncionamiento(void){
	
	switch(modos){
		case REPOSO:
			
			reposo();
			osMessageQueueGet(mid_MsgQueueJOY,&pulsacion, NULL, 1000U);
			if((pulsacion.corta == 0) && (pulsacion.direccion == CENTRO))
			{
				modos = ACTIVO;
			}
			break;
					
		case ACTIVO:
			
			activo();
			osMessageQueueGet(mid_MsgQueueJOY,&pulsacion, NULL, 1000U);
			if((pulsacion.corta == 0) && (pulsacion.direccion == CENTRO))
			{
				modos = TEST;
			}
			break;
		
		case TEST:
			
			test();
			osMessageQueueGet(mid_MsgQueueJOY,&pulsacion, NULL, 1000U);
			if((pulsacion.corta == 0) && (pulsacion.direccion == CENTRO))
			{
				modos = PROGRAMACION;
			}
			break;
		
		case PROGRAMACION:
			
			programacion();
			osMessageQueueGet(mid_MsgQueueJOY,&pulsacion, NULL, 1000U);
			if((pulsacion.corta == 0) && (pulsacion.direccion == CENTRO))
			{
				modos = REPOSO;
			}
			break;

	}
}

void principal (void *argument) {
	pulsacion.direccion = 0x00;
	
  while (1) {
		
		modoFuncionamiento();
    
    osThreadYield();                            // suspend thread
  }
}
